const express = require('express');
const app = express();
const chalk = require('chalk');

const {getUsers, getUserById, putUserById} = require('./src/teste');

app.get('/', (req, res)=>{
    res.send('Olá, este é o endereço raiz');
});

app.get('/api/v1/users', async (req, res) =>{
    res.json(await getUsers());
})

app.get('/api/v1/users/:id', async (req, res) => {
    res.json(await getUserById(req.params.id));
});

app.put('/api/v1/users/:id', async(req, res) => {
    res.json("Isso é um put!");
    console.log("passei aqui 1 2 3 4 ******");
    console.log(res);
    //res.json(await putUserById(req.params.id));
    
})

// app.post('/api/v1/users', function(req, res) {
//     console.log(req.body);
//     res.json(req.body);
//    });
// server.post('/geeks', checkUserExists, (req, res) => {
//     const { name } = req.body; // assim esperamos buscar o name informado dentro do body da requisição
//     geeks.push(name);
//     return res.json(geeks); // retorna a informação da variável geeks
//     })


app.listen(4010, ()=>{
    console.log('Listening on port '+ chalk.green('3000'));
});
